package com.uno.getinline.constant;

public enum PlaceType {
    COMMON, SPORTS, RESTAURANT, PARTY
}
