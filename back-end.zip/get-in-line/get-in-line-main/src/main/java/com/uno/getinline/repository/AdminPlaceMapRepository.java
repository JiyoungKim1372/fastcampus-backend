package com.uno.getinline.repository;

import com.uno.getinline.domain.AdminPlaceMap;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdminPlaceMapRepository extends JpaRepository<AdminPlaceMap, Long> {
}
