package com.uno.getinline.constant;

public enum EventStatus {
    PENDING, OPENED, CLOSED, CANCELLED, ABORTED
}
