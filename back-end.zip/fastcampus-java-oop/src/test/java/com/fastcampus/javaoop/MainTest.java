package com.fastcampus.javaoop;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MainTest {

    @Test
    void main() {
        // Given
        String[] args = {"3", "1", "2"};

        // When & Then
        Main.main(args);

    }
}