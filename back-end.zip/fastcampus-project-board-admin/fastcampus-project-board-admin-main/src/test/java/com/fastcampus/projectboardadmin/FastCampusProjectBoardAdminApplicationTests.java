package com.fastcampus.projectboardadmin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@ActiveProfiles("test")
@SpringBootTest
class FastCampusProjectBoardAdminApplicationTests {

    @Test
    void contextLoads() {
    }

}
