package com.fastcampus.programming.dmaker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DmakerApplicationTests {

	@Test
	void contextLoads() {
	}

}
